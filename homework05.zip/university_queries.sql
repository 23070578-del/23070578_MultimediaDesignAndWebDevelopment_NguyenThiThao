
/*
 * Student Name: Nguyen Thi Thao
 * Student ID: 23070578
 * Assignment: Homework 5 - University Queries
 * Date: 2026-10-12
 */

USE university_db;


/*
 * Query 1: List All Students
 * Description: Retrieves all columns from the students table
 *              to display every student record.
 * Expected Output: All 5 student records with all columns.
 */
SELECT *
FROM students;

/*
 * Expected Output (abbreviated example):
 * +----+-------------+-----------------+-------+
 * | id | student_code| full_name       | gpa   |
 * +----+-------------+-----------------+-------+
 * |  1 | SV2026001   | Nguyen Thi Lan  | 3.45  |
 * |  2 | SV2026002   | Tran Quoc Bao   | 3.10  |
 * |  3 | SV2026003   | Le Thu Trang    | 3.75  |
 * |  4 | SV2026004   | Pham Duc Long   | 2.95  |
 * |  5 | SV2026005   | Hoang Ngoc Anh  | 3.60  |
 * +----+-------------+-----------------+-------+
 * (5 rows; other columns are omitted from this example)
 */


/*
 * Query 2: Students with GPA Greater Than 3.0
 * Description: Filters students whose GPA is greater than 3.0.
 * Expected Output: Students with GPA above 3.0.
 */
SELECT id, student_code, full_name, gpa
FROM students
WHERE gpa > 3.0
ORDER BY id;

/*
 * Expected Output:
 * +----+-------------+-----------------+------+
 * | id | student_code| full_name       | gpa  |
 * +----+-------------+-----------------+------+
 * |  1 | SV2026001   | Nguyen Thi Lan  | 3.45 |
 * |  2 | SV2026002   | Tran Quoc Bao   | 3.10 |
 * |  3 | SV2026003   | Le Thu Trang    | 3.75 |
 * |  5 | SV2026005   | Hoang Ngoc Anh  | 3.60 |
 * +----+-------------+-----------------+------+
 * (4 rows)
 */


/*
 * Query 3: Students Matching GPA or Department Conditions
 * Description: Uses OR to find students with GPA >= 3.50
 *              or students belonging to department 1.
 * Expected Output: Students satisfying at least one condition.
 */
SELECT id, full_name, gpa, department_id
FROM students
WHERE gpa >= 3.50 OR department_id = 1
ORDER BY id;

/*
 * Expected Output:
 * +----+-----------------+------+---------------+
 * | id | full_name       | gpa  | department_id |
 * +----+-----------------+------+---------------+
 * |  1 | Nguyen Thi Lan  | 3.45 | 1             |
 * |  3 | Le Thu Trang    | 3.75 | 3             |
 * |  5 | Hoang Ngoc Anh  | 3.60 | 5             |
 * +----+-----------------+------+---------------+
 * (3 rows)
 */


/*
 * Query 4: Sort Students by Name
 * Description: Sorts all students alphabetically by full_name.
 * Expected Output: All 5 students in ascending name order.
 */
SELECT id, student_code, full_name, gpa
FROM students
ORDER BY full_name ASC;

/*
 * Expected Output:
 * +----+-------------+-----------------+------+
 * | id | student_code| full_name       | gpa  |
 * +----+-------------+-----------------+------+
 * |  5 | SV2026005   | Hoang Ngoc Anh  | 3.60 |
 * |  3 | SV2026003   | Le Thu Trang    | 3.75 |
 * |  1 | SV2026001   | Nguyen Thi Lan  | 3.45 |
 * |  4 | SV2026004   | Pham Duc Long   | 2.95 |
 * |  2 | SV2026002   | Tran Quoc Bao   | 3.10 |
 * +----+-------------+-----------------+------+
 * (5 rows)
 */


/*
 * Query 5: Top 3 Highest-Graded Enrollments
 * Description: Sorts enrollments by grade_point from highest
 *              to lowest and returns only the top 3.
 * Expected Output: The 3 highest non-NULL grade_point values.
 */
SELECT id, student_id, course_id, grade_point
FROM enrollments
WHERE grade_point IS NOT NULL
ORDER BY grade_point DESC, id ASC
LIMIT 3;

/*
 * Expected Output:
 * +----+------------+-----------+-------------+
 * | id | student_id | course_id | grade_point |
 * +----+------------+-----------+-------------+
 * |  9 | 5          | 1         | 3.90        |
 * |  5 | 3          | 4         | 3.80        |
 * |  2 | 1          | 2         | 3.75        |
 * +----+------------+-----------+-------------+
 * (3 rows)
 */


/*
 * Query 6: Search Courses Containing Web
 * Description: Uses LIKE with % to find course names
 *              containing the word "Web".
 * Expected Output: Courses whose course_name contains "Web".
 */
SELECT course_code, course_name
FROM courses
WHERE course_name LIKE '%Web%'
ORDER BY course_code;

/*
 * Expected Output:
 * +-------------+---------------------------+
 * | course_code | course_name               |
 * +-------------+---------------------------+
 * | INS3064     | Web Design and Development|
 * +-------------+---------------------------+
 * (1 row)
 */


/*
 * Query 7: Count Students in Each Department
 * Description: Uses COUNT and LEFT JOIN to count students
 *              in every department, including departments
 *              with no students.
 * Expected Output: Department names and their student counts.
 */
SELECT
    d.name AS department_name,
    COUNT(s.id) AS student_count
FROM departments AS d
LEFT JOIN students AS s
    ON d.id = s.department_id
GROUP BY d.id, d.name
ORDER BY d.id;

/*
 * Expected Output:
 * +----------------------+---------------+
 * | department_name      | student_count |
 * +----------------------+---------------+
 * | Information Technology | 1           |
 * | Business Administration | 1         |
 * | Finance and Banking  | 1             |
 * | Marketing            | 1             |
 * | English Studies      | 1             |
 * +----------------------+---------------+
 * (5 rows)
 */


/*
 * Query 8: Departments Offering Courses
 * Description: Groups courses by department and uses HAVING
 *              to display only departments offering at least
 *              one course.
 * Expected Output: Departments and their course counts.
 */
SELECT
    d.name AS department_name,
    COUNT(c.id) AS course_count
FROM departments AS d
JOIN courses AS c
    ON d.id = c.department_id
GROUP BY d.id, d.name
HAVING COUNT(c.id) > 0
ORDER BY d.id;

/*
 * Expected Output:
 * +-------------------------+--------------+
 * | department_name         | course_count |
 * +-------------------------+--------------+
 * | Information Technology  | 2            |
 * | Business Administration | 1            |
 * | Finance and Banking     | 1            |
 * | Marketing               | 1            |
 * +-------------------------+--------------+
 * (4 rows)
 */


/*
 * Query 9: Courses with Instructor Names
 * Description: Joins courses and instructors through the
 *              instructor_id foreign key.
 * Expected Output: Each course with its instructor's name.
 */
SELECT
    c.course_code,
    c.course_name AS course_title,
    i.full_name AS instructor_name
FROM courses AS c
JOIN instructors AS i
    ON c.instructor_id = i.id
ORDER BY c.id;

/*
 * Expected Output:
 * +-------------+-----------------------------+-----------------+
 * | course_code | course_title                | instructor_name |
 * +-------------+-----------------------------+-----------------+
 * | INS3064     | Web Design and Development  | Nguyen Van An   |
 * | INS3022     | Database Systems            | Nguyen Van An   |
 * | BUS2001     | Principles of Management    | Tran Thi Binh   |
 * | FIN2001     | Corporate Finance           | Le Minh Hoang   |
 * | MKT2001     | Principles of Marketing     | Pham Thu Ha     |
 * +-------------+-----------------------------+-----------------+
 * (5 rows)
 */


/*
 * Query 10: Enrollment Details
 * Description: Joins enrollments with students, courses,
 *              and semesters to display complete registration
 *              information and grades.
 * Expected Output: 10 enrollment records with student names,
 *                  course titles, semesters, and grade points.
 */
SELECT
    e.id AS enrollment_id,
    s.full_name AS student_name,
    c.course_name AS course_title,
    sem.name AS semester_name,
    e.grade_point
FROM enrollments AS e
JOIN students AS s
    ON e.student_id = s.id
JOIN courses AS c
    ON e.course_id = c.id
JOIN semesters AS sem
    ON e.semester_id = sem.id
ORDER BY e.id;

/*
 * Expected Output:
 * +--------------+-----------------+--------------------------+---------------+-------------+
 * | enrollment_id| student_name    | course_title             | semester_name | grade_point |
 * +--------------+-----------------+--------------------------+---------------+-------------+
 * | 1            | Nguyen Thi Lan  | Web Design and Development | Spring 2026 | 3.50        |
 * | 2            | Nguyen Thi Lan  | Database Systems         | Spring 2026   | 3.75        |
 * | 3            | Tran Quoc Bao   | Principles of Management | Spring 2026   | 3.00        |
 * | 4            | Tran Quoc Bao   | Web Design and Development | Fall 2026   | NULL        |
 * | 5            | Le Thu Trang    | Corporate Finance        | Spring 2026   | 3.80        |
 * | 6            | Le Thu Trang    | Principles of Marketing  | Fall 2026     | NULL        |
 * | 7            | Pham Duc Long   | Database Systems         | Fall 2025     | 2.75        |
 * | 8            | Pham Duc Long   | Principles of Management | Fall 2026     | NULL        |
 * | 9            | Hoang Ngoc Anh  | Web Design and Development | Spring 2026 | 3.90        |
 * | 10           | Hoang Ngoc Anh  | Principles of Marketing  | Fall 2026     | NULL        |
 * +--------------+-----------------+--------------------------+---------------+-------------+
 * (10 rows)
 */
